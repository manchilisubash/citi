export class Employee{ 
    public name :string; 
    public dob:string; 
    public email:string; 
    public eid:number; 
constructor(n:string, dob:string, em:string, e:number)
{ this.name=n; this.dob=dob; this.email=em; this.eid=e; } 
}