import { SearchbynamePipe } from './searchbyname.pipe';

describe('SearchbynamePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchbynamePipe();
    expect(pipe).toBeTruthy();
  });
});
